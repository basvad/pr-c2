const progress_cats = document.querySelector('.cats');
const progress_parrots = document.querySelector('.parrots');
const progress_dogs = document.querySelector('.dogs');

const header = new Headers({
    //Если включен режим учетных данных запроса (Request.credentials), браузеры будут предоставлять ответ на код JavaScript внешнего интерфейса только в том случае, если значение Access-Control-Allow-Credentials имеет значение true.
    'Access-Control-Allow-Credentials': true,
    'Access-Control-Allow-Origin': '*'
})

const url = new URL('https://sf-pyw.mosyag.in/sse/vote/stats')
const ES = new EventSource(url, header)
//обрабатываем ошибку
ES.onerror = error => {
    ES.readyState ? progress.textContent = "Some error" : null;
}
//обработка сообщения
ES.onmessage = message => {
    //распарсить JSON
   let votesObj = JSON.parse(message.data);
   //считаем сумму всех голосов
   let sum_votes = votesObj['cats']+votesObj['parrots']+votesObj['dogs'];
   //Процент голосов за кошек
   let cats_votes = ((votesObj['cats']/sum_votes)*100).toFixed(1);
   //Процент голосов за попугаев
   let parrots_votes = ((votesObj['parrots']/sum_votes)*100).toFixed(1);
    //Процент голосов за собак
   let dogs_votes = ((votesObj['dogs']/sum_votes)*100).toFixed(1);
   // отладочный вывод
  // console.log(votesObj);
   //меняем значение прогресс бара кошек
   progress_cats.style.cssText = `width: ${cats_votes}%;`
   // меняем подпись прогресс бара для кошек
   progress_cats.textContent = `${cats_votes}% / ( ${votesObj['cats']} )`;
   //меняем значение прогресс бара попугаев
   progress_parrots.style.cssText = `width: ${parrots_votes}%`;
   // меняем подпись прогресс бара для попугаев
   progress_parrots.textContent = `${parrots_votes}% / ( ${votesObj['parrots']} )`;
   //меняем значение прогресс бара собак
   progress_dogs.style.cssText = `width: ${dogs_votes}%`;
   // меняем подпись прогресс бара для собак
   progress_dogs.textContent = `${dogs_votes}% / ( ${votesObj['dogs']} )`;
}
