//получаем форму
const form = document.querySelector('form');
// постоянная часть адреса
let server_url = 'https://sf-pyw.mosyag.in/sse/vote/'
//вешаем обработчик события submit
form.addEventListener('submit',function(event){
    //добавляем к постоянной части переменную в виде value выбранного чекбокса
    server_url+=form.elements.vote.value;
    //меняем атрибут action у формы
    form.setAttribute('action',server_url);
    });

